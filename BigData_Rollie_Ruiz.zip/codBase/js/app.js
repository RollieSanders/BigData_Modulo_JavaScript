var num1 = 0,num2 = 0,operaciones='',resultado = 0;

var img = document.querySelectorAll('img[class~="tecla"]');

// var img9 = document.querySelector('img[alt="9"]');


// img9.addEventListener('mousedown', function(ev){
    
//         ev.target.style = "width: 20%";
 
// })

// img9.addEventListener('mouseup', function(ev){
    
//     ev.target.style = "width: 22%";

// })

function formaOriginal(ev){
    
    var imagen = document.getElementById(ev.srcElement.id).style = "width: 10%"
    // console.log(ev);
    // var imagen = document.getElementById(srcElement.id)
    // ev.target.style = "width: 22%";
}

// img9.addEventListener('blur', function(ev){
//     ev.target.style = "width: 50%";
//     //console.log(ev);
// })

var teclado = document.querySelector(".teclado")
// img.addEventListener('click', function(event) {
//     event.preventDefault();
//     alert('HOLA');
// });  
var visualiza = document.getElementById('display')
var numero = visualiza.textContent;


//visualiza.innerHTML = e.target.alt
for (i = 0; i < img.length; i++) {
    img[i].onclick = function(e){
        e.preventDefault();
        numero = visualiza.innerHTML;
        
        switch (e.target.alt) {
            case 'On':
                visualiza.innerHTML = '0'
                break;
            case 'punto':
                puntoComa();
                break;
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                digitaNumero(e.target.alt);
                break;
            case 'signo':
                agregarSigno()
                break;
            case 'mas':
            case 'menos':
            case 'por':
            case 'dividido':
                num1 = visualiza.innerHTML;
                visualiza.innerHTML = '0';
                operaciones = e.target.alt
                break;
            case 'igual':
                
                num2 = visualiza.innerHTML;
                operacionMatematica(num1,num2,operaciones)
                break;
            default:
                break;
        }
        
        
    }

    img[i].onmousedown = function(e){
        e.target.style.padding = "1px"
    }

    img[i].onmouseup = function(e){
       e.target.style.padding = "0px"
    }
}

function operacionMatematica(num1,num2,operacion){
    switch (operacion) {
        case 'mas':
        
        visualiza.innerHTML = suma(num1,num2);
            break;
        case 'menos':
        visualiza.innerHTML = resta(num1,num2);
            break;
        case 'por':
        visualiza.innerHTML = multiplicacion(num1,num2);
            break;
        case 'dividido':
        visualiza.innerHTML = division(num1,num2);
        default:
            break;
    }

}

function suma(num1,num2){
    return parseFloat(num1) + parseFloat(num2)
}
function multiplicacion(num1,num2){
    return parseFloat(num1) * parseFloat(num2)
}

function division(num1,num2){
    return parseFloat(num1) / parseFloat(num2)
}

function resta(num1,num2){
    return parseFloat(num1) - parseFloat(num2)
}
function agregarSigno(){
    
    if (numero == '0') {
        numero = '0';
    }else if(numero.indexOf('-') == -1){
        numero = numero.replace('-','')
        numero = '-'+numero;
    }else{
        numero = numero.replace('-','')
        numero = ''+numero;
    }
    visualiza.innerHTML = numero;

}
function digitaNumero(num){
    if(numero==0){
        numero = num
    }else{
        numero = numero +''+ num;
    }
    
    if(numero.length <= 8)
    visualiza.innerHTML = numero
}
function puntoComa(){
    if (numero == '0') {
        numero = '0.';
    }else if(numero.indexOf('.') == -1){
        numero = numero + '.';
    }
    visualiza.innerHTML = numero;
}

// initCalculadora();
// alert('ff');
// function initCalculadora() {
//     Calculadora.init()
// }


// var Calculadora = {
//     init : function(){
//     loadCalculadora()
//     //   this.suma()
//     //   this.resta()
//     //   this.multiplicacion()
//     //   this.division()
//     //   this.mostrarNumero()

      
//     },
//     loadCalculadora: function(){
//         var img = document.querySelectorAll('img[class="tecla"]')
//         img.onclick = function(e){
//             alert(e);
//         }
//     },
//     suma: function(){

//     },
//     resta: function(){

//     },
//     multiplicacion: function(){

//     },
//     division: function(){

//     },
//     mostrarNumero: function(numero){
//         if (num1==0 && num1!== '0.') {
//             num1 = numero
//         }else{
//             num1 += numero
//         }
//         document.getElementById('display').value = num1
//     },
//     resultado: function(){
//         return resultado
//     }

// }


// var Calculadora = (function(num1,num2){
//     var resultado = 0;
//     function actualizarResultado(nuevoResultado){
//         resultado = nuevoResultado;
//     }
//     return {
//         sumar: function(){
//             var resultado = num1 + num2;
//             actualizarResultado(resultado);
//         },
//         restar: function(){
//             var resultado = num1 - num2;
//             actualizarResultado(resultado);
//         },
//         multiplicar: function(){
//             var resultado = num1 * num2;
//             actualizarResultado(resultado);
//         },
//         dividir: function(){
//             var resultado = num1 / num2;
//             actualizarResultado(resultado);
//         },
//         resultado: function(){
//             return resultado;
//         }

//     }
// })