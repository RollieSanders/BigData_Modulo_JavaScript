var num1 = 0, num2 = 0, operaciones = '',resultado = 0;
var img = document.querySelectorAll('img[class~="tecla"]');
var visualiza = document.getElementById('display')
var numero = visualiza.textContent;
$(document).ready(function(){
    Calculadora.init()
});


var Calculadora = {
    init : function(){
        this.listenCalculadoraClick()
        this.agregarSigno()
        this.digitaNumero()
        this.punto()
    },
    listenCalculadoraClick: function(){
        var self = this
        for (i = 0; i < img.length; i++) {
            img[i].onclick = function(e){
                e.preventDefault()
                numero = visualiza.innerHTML
                
                switch (e.target.alt) {
                    case 'On':
                        visualiza.innerHTML = '0'
                        break;
                    case 'punto':
                        self.punto();
                        break;
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        self.digitaNumero(e.target.alt)
                        break;
                    case 'signo':
                        self.agregarSigno()
                        break;
                    case 'mas':
                    case 'menos':
                    case 'por':
                    case 'dividido':
                        num1 = visualiza.innerHTML
                        visualiza.innerHTML = '0'
                        operaciones = e.target.alt
                        break;
                    case 'igual':
                        num2 = visualiza.innerHTML
                        self.operacionMatematica(num1,num2,operaciones)
                        break;
                    default:
                        break;
                }
                
                
            }

            img[i].onmousedown = function(e){
                e.target.style.padding = "1px"
            }
        
            img[i].onmouseup = function(e){
               e.target.style.padding = "0px"
            }
        }
    },
    punto: function(){
        if (numero == '0') {
            numero = '0.'
        }else if(numero.indexOf('.') == -1){
            numero = numero + '.'
        }
        visualiza.innerHTML = numero
    },
    digitaNumero: function(num){
        if(numero==0){
            numero = num
        }else{
            numero = numero +''+ num
        }
        
        if(numero.length <= 8)
        visualiza.innerHTML = numero
    },
    agregarSigno: function(){
        if (numero == '0') {
            numero = '0';
        }else if(numero.indexOf('-') == -1){
            numero = numero.replace('-','')
            numero = '-'+numero;
        }else{
            numero = numero.replace('-','')
            numero = ''+numero;
        }
        visualiza.innerHTML = numero;
    },
    suma: function(num1,num2){
        return parseFloat(num1) + parseFloat(num2)
    },
    multiplicacion: function(num1,num2){
        return parseFloat(num1) * parseFloat(num2)
    },
    divison: function(num1,num2){
        return parseFloat(num1) / parseFloat(num2)
    },
    resta: function(num1,num2){
        return parseFloat(num1) - parseFloat(num2)
    },
    operacionMatematica: function(num1,num2,operacion){
        switch (operacion) {
            case 'mas':
                visualiza.innerHTML = this.suma(num1,num2);
                break;
            case 'menos':
                visualiza.innerHTML = this.resta(num1,num2);
                break;
            case 'por':
                visualiza.innerHTML = this.multiplicacion(num1,num2);
                break;
            case 'dividido':
                visualiza.innerHTML = this.division(num1,num2);
            default:
                break;
        }
    }

}
